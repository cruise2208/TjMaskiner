<?php if (is_active_sidebar('envo-marketplace-top-bar-area')) { ?>
    <div class="top-bar-section container-fluid">
        <div class="<?php echo esc_attr(get_theme_mod('top_bar_content_width', 'container')); ?>">
            <div class="row">
                <?php dynamic_sidebar('envo-marketplace-top-bar-area'); ?>
            </div>
        </div>
    </div>
<?php } ?>
<div class="site-header container-fluid">
    <div class="<?php echo esc_attr(get_theme_mod('header_content_width', 'container')); ?>" >
        <div class="heading-row row" >
            <div class="site-heading <?php echo esc_attr(class_exists('WooCommerce') == true ? 'col-md-3' : 'col-md-6' ); ?>" >
                <?php envo_marketplace_title_logo(); ?>
            </div>
            <div class="menu-heading col-md-6">
                <nav id="site-navigation" class="navbar navbar-default">
                    <?php 
                    wp_nav_menu(array(
                        'theme_location' => 'main_menu',
                        'depth' => 5,
                        'container_id' => 'my-menu',
                        'container' => 'div',
                        'container_class' => 'menu-container',
                        'menu_class' => 'nav navbar-nav navbar-left',
                        'fallback_cb' => 'Envo_Marketplace_WP_Bootstrap_Navwalker::fallback',
                        'walker' => new Envo_Marketplace_WP_Bootstrap_Navwalker(),
                    ));
                    ?>
                </nav>    
                <?php if (is_active_sidebar('envo-marketplace-header-area')) { ?>
                    <div class="site-heading-sidebar" >
                        <?php dynamic_sidebar('envo-marketplace-header-area'); ?>
                    </div>
                <?php } ?>
            </div>
            <?php if (class_exists('WooCommerce')) { ?>
                <div class="header-right col-md-3" >
                    <div class="navbar-header">
                <?php if (function_exists('max_mega_menu_is_enabled') && max_mega_menu_is_enabled('main_menu')) : ?>
                <?php else : ?>
                    <span class="navbar-brand brand-absolute visible-xs"><?php esc_html_e('Menu', 'envo-marketplace'); ?></span>

                    <a href="#" id="main-menu-panel" class="open-panel" data-panel="main-menu-panel">
                        <span></span>
                        <span></span>
                        <span></span>
                    </a>
                <?php endif; ?>
            </div>
                    <?php envo_marketplace_header_cart(); ?>
                    <?php envo_marketplace_my_account(); ?>
                    <?php envo_marketplace_head_wishlist(); ?>
                    <?php envo_marketplace_head_compare(); ?>
                </div>	
            <?php } ?>
        </div>
    </div>
</div>
<?php do_action('envo_marketplace_before_menu'); ?> 
<div class="main-menu">
    <nav id="second-site-navigation" class="navbar navbar-default <?php envo_marketplace_second_menu(); ?>">
        <div class="container">   
            
            <?php
            envo_marketplace_categories_menu();
            
            if (class_exists('WooCommerce')) { ?>
                    <div class="header-search-form">
                        <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                            <input type="hidden" name="post_type" value="product" />
                            <input class="header-search-input" name="s" type="text" placeholder="<?php esc_attr_e('Search products...', 'envo-marketplace'); ?>"/>
                            <select class="header-search-select" name="product_cat">
                                <option value=""><?php esc_html_e('All Categories', 'envo-marketplace'); ?></option> 
                                <?php
                                $categories = get_categories('taxonomy=product_cat');
                                foreach ($categories as $category) {
                                    $option = '<option value="' . esc_attr($category->category_nicename) . '">';
                                    $option .= esc_html($category->cat_name);
                                    $option .= ' <span>(' . absint($category->category_count) . ')</span>';
                                    $option .= '</option>';
                                    echo $option; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                }
                                ?>
                            </select>
                            <button class="header-search-button" type="submit"><i class="la la-search" aria-hidden="true"></i></button>
                        </form>
                    </div>
                <?php } 
            if (has_nav_menu('main_menu_right')) {    
                wp_nav_menu(array(
                    'theme_location' => 'main_menu_right',
                    'depth' => 1,
                    'container_id' => 'my-menu-right',
                    'container' => 'div',
                    'container_class' => 'menu-container',
                    'menu_class' => 'nav navbar-nav navbar-right',
                    'fallback_cb' => 'Envo_Marketplace_WP_Bootstrap_Navwalker::fallback',
                    'walker' => new Envo_Marketplace_WP_Bootstrap_Navwalker(),
                ));
            }
            ?>
        </div>
        <?php do_action('envo_marketplace_menu'); ?>
    </nav> 
</div>
<?php do_action('envo_marketplace_after_menu'); ?>
